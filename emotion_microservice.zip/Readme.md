# Microservie for Predicting mental state based on different Data
## Used as a component in the development of CalmQuest in the Aces Hackathon
